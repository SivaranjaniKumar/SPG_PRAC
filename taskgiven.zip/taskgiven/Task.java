package com.cap.taskgiven;

import javax.persistence.*;
@Entity
public class Task {
	@Id
	  @GeneratedValue
	  private long id;
	  private String name;
	  @OneToOne
	  private Employee supervisor;
	  public String getName() {
	        return name;
	    }

	    public void setName(String name) {
	        this.name = name;
	    }

	    public Employee getSupervisor() {
	        return supervisor;
	    }

	    public void setSupervisor(Employee supervisor) {
	        this.supervisor = supervisor;
	    }

	    public static Task create(String name) {
	        Task task = new Task();
	        task.setName(name);
	        return task;
	    }

	    @Override
	    public String toString() {
	        return "Task{" +
	                "id=" + id +
	                ", name='" + name + '\'' +
	                '}';
	    }
}
