package com.cap.taskgiven;

import java.util.Arrays;
import java.util.List;

import javax.persistence.*;

public class TableMappingMain {
	private static EntityManagerFactory entityManagerFactory =
	          Persistence.createEntityManagerFactory("Testpersistence");

	  public static void main(String[] args) {
	      try {
	          nativeQuery("SHOW TABLES");
	          nativeQuery("SHOW COLUMNS FROM EMPLOYEE");
	          nativeQuery("SHOW COLUMNS FROM EMPLOYEE_PHONENUMBERS");
	          nativeQuery("SHOW COLUMNS FROM EMPLOYEE_TASK");
	          nativeQuery("SHOW COLUMNS FROM TASK");
	          nativeQuery("SHOW COLUMNS FROM EMPLOYEE_ADDRESSES");

	      } finally {
	          entityManagerFactory.close();
	      }
	  }

	  public static void nativeQuery(String s) {
	      EntityManager em = entityManagerFactory.createEntityManager();
	      System.out.printf("'%s'%n", s);
	      Query query = em.createNativeQuery(s);
	      List list = query.getResultList();
	      for (Object o : list) {
	          if (o instanceof Object[]) {
	              System.out.println(Arrays.toString((Object[]) o));
	          } else {
	              System.out.println(o);
	          }
	      }
	      em.close();
	  }
}
