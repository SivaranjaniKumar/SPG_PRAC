package com.cap.practise;

public class InnovaCar extends Car {
	
	String mileage ;
	public InnovaCar(int b) {
		super(false,"6");
		this.mileage=Integer.toString(b);
		getMileage();
	}

	@Override
	public String getMileage() {
		
		return mileage;
	}

}
