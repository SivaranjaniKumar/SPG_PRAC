package com.cap.practise;

import java.util.Scanner;

public class AbstractImpl {
	
	public static void main(String args[]) {
		
		@SuppressWarnings("resource")
		Car car;
		Scanner scan = new Scanner(System.in);
				
		System.out.println("You entered number between 0-2 ");
        int a = scan.nextInt();
        if(a>=0 && a<=2) {        
        System.out.println("You entered perfered milage");
        int b = scan.nextInt();
        if (b>=5 && b<=30) {
              if(a==0) {
            	car= new WagonR(b);
            	  System.out.println("A WagonR is not Sedan, is "+ car.getSeats()+"-Seater, and has"
          				+ "a millage of arround "+ car.getMileage()+"kmpl");          }
              else if(a==1){
            	car= new HondaCity(b);
            	  System.out.println("A HondaCity is Sedan, is "+car.getSeats()+"-Seater, and has"
          				+ "a millage of arround "+ car.getMileage() +"kmpl");
              } else if (a==2) {
            	 car= new InnovaCar(b);
            	 System.out.println("A Innova is not Sedan, is "+car.getSeats()+"-Seater, and has"
           				+ "a millage of arround "+ car.getMileage() +"kmpl");
              }
              }
        }
        else {
        	System.out.println("Enter a valid number");
        }
		
	}

}
