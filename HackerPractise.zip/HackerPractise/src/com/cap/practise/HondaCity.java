package com.cap.practise;

public class HondaCity extends Car {
	
	String mileage ;
	
	public HondaCity(int b) {
		super(true,"4");
		this.mileage=Integer.toString(b);
		getMileage();
	}

	@Override
	public String getMileage() {
		
		return mileage;
		// TODO Auto-generated method stub
		
	}

}
