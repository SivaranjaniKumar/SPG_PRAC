package com.cap.practise;

public class WagonR extends Car {

	String mileage;

	public WagonR(int b) {
		super(false, "4");
		this.mileage = Integer.toString(b);
		getMileage();
	}

	@Override
	public String getMileage() {
		return mileage;
	}

}
