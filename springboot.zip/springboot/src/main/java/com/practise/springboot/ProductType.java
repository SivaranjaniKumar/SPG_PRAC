package com.practise.springboot;

public class ProductType {
	public enum productType{
		Pen,
		Pencile,
		NoteBook,
		}

}
