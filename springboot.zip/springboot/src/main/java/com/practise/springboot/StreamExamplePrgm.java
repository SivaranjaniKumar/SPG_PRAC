package com.practise.springboot;

public class StreamExamplePrgm {
	public static void main(String[] args) {
	//	Product pen = new Product("Renols",ProductType.Pen);
	}
	
	/*
	 * class Product{ private String name; private ProductType productType;
	 * 
	 * public String getName() { return name; } public void setName(String name) {
	 * this.name = name; } public ProductType getProductType() { return productType;
	 * } public void setProductType(ProductType productType) { this.productType =
	 * productType; }
	 * 
	 * }
	 */

}
